﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MediAssisApp
{
    public partial class RegisterDoctor : System.Web.UI.Page
    {
        Models.Doctor objDoc = new Models.Doctor();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("DoctorLogin.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            objDoc.Name = txtName.Text;
            objDoc.Email = txtEmail.Text;
            objDoc.MobileNo = txtMobNo.Text;
            objDoc.Pwd = txtPwd.Text;
            objDoc.RegistrationNo = txtRegNo.Text;
            objDoc.Degree = ddlDrDegree.SelectedValue;

            // Check if email is already exist in db

            int isDocAdded = objDoc.RegisterDocDetails();

            if(isDocAdded >0)
            {
                lblMsg.Text = "Doctor is added successfully!";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
        }
    }
}