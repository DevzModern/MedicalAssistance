﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace MediAssisApp
{
    public partial class RegisterPatient : System.Web.UI.Page
    {
        Models.Patient objPatient = new Models.Patient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            objPatient.Name = txtName.Text;
            objPatient.Email = txtEmail.Text;
            objPatient.MobileNo = txtMobNo.Text;
            objPatient.Pwd = txtPwd.Text;
            objPatient.Address = txtAddress.Text;

            // Check if email is already exist in db
            DataTable tempDT = objPatient.CheckIfEmailRegistered();

            if (tempDT != null && tempDT.Rows.Count > 0)
            {
                lblMsg.Text = "Email id is already registered!";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                int isPatientAdded = objPatient.RegisterPatientDetails();
                Session["RegisteredPatientID"] = isPatientAdded;

                if (isPatientAdded > 0)
                {
                    lblMsg.Text = "Patient is added successfully! " +
                                  "<a href=\"LinkAadharNo.aspx\">Click Here</a> To Link Aadhar / <a href=\"PatientLogin.aspx\">Skip to login</a>";
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("PatientLogin.aspx");
        }
    }
}