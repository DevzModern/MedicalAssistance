﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MediAssisApp.Models
{
    public class PatientMediclaimPolicy
    {
        public string MediclaimPolicyNo { get; set; }
        public string Company { get; set; }
        public string SumAssured { get; set; }
        public string Duration { get; set; }
        public int Patient_Id { get; set; }

        public int InsertMediclaimPolicy()
        {
            string[] paramName = { "@MediclaimPolicyNo",
                                   "@Company",
                                   "@SumAssured",
                                   "@Duration",
                                   "@Patient_Id"

            };
            object[] paramValue = { MediclaimPolicyNo,
                                    Company,
                                    SumAssured,
                                    Duration,
                                    Patient_Id
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_InsertMediPolicy", false);
            }
            catch
            {
                return 0;
            }
        }
    }
}