﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class LoginDetails
    {
        public static DataTable ValidateDocCredentials(string email, string password)
        {
            string[] paramName = { "@Email", "@Password" };
            object[] paramValue = { email, password };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_ValidateDoctor");
            }
            catch
            {
                return null;
            }
        }

        public static DataTable ValidatePatientCredentials(string email, string password)
        {
            string[] paramName = { "@Email", "@Password" };
            object[] paramValue = { email, password };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_ValidatePatient");
            }
            catch
            {
                return null;
            }
        }

        public static DataTable LicenseExpired()
        {
            string[] paramName = { };
            object[] paramValue = { };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_LicenseExpired");
            }
            catch
            {
                return null;
            }
        }
    }
}