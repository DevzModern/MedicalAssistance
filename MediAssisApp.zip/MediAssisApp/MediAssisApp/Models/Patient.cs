﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class Patient
    {
        public int PatientId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string Pwd { get; set; }
        public string Address { get; set; }
        public string AadharNo { get; set; }

        public int RegisterPatientDetails()
        {
            string[] paramName = { "@Name",
                                   "@Email",
                                   "@MobileNo",
                                   "@Pwd",
                                   "@Address"

            };
            object[] paramValue = { Name,
                                    Email,
                                    MobileNo,
                                    Pwd,
                                    Address
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_RegisterPatient", true);
            }
            catch
            {
                return 0;
            }
        }

        public DataTable CheckIfEmailRegistered()
        {
            string[] paramName = { "@EmailId" };
            object[] paramValue = { Email };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_CheckIfEmailIdRegistered");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetDetailsByAadharNo(string aadharNo)
        {
            string[] paramName = { "@AadharNo" };
            object[] paramValue = { aadharNo };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDetailsByAadharNo");
            }
            catch
            {
                return null;
            }
        }

        public int LinkAadharNo(int patientId, string aadharNo)
        {
            string[] paramName = { "@PatientId",
                                   "@AadharNo"

            };
            object[] paramValue = { patientId, 
                                    aadharNo
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_LinkAadharNo", true);
            }
            catch
            {
                return 1;
            }
        }

        public DataTable GetDetailsByPatientId()
        {
            string[] paramName = { "@PatientId" };
            object[] paramValue = { PatientId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDetailsByPatientId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetPtientHealthDetailsByAadharNo(string aadharNo)
        {
            string[] paramName = { "@AadharNo" };
            object[] paramValue = { aadharNo };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetPtientHealthDetailsByAadharNo");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetMediPoliciesByPatientId(string patientId)
        {
            string[] paramName = { "@PatientId" };
            object[] paramValue = { patientId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetMediPolicyByPatientId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable CheckIfAadharisLinked()
        {
            string[] paramName = { "@PatientId" };
            object[] paramValue = { PatientId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_CheckIfAadharisLinked");
            }
            catch
            {
                return null;
            }
        }

        public int UpdateAadhar()
        {
            string[] paramName = { "@Aadhar_Info_Id", "@PatientId" };
            object[] paramValue = { AadharNo, PatientId };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateAadharLink");
            }
            catch
            {
                return 0;
            }
        }
    }
}