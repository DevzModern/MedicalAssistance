﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public string Speciality { get; set; }
        public string OPDLocation { get; set; }
        public string AppointmentDate { get; set; }
        public string TimeSlot { get; set; }
        public int Doctor_Id { get; set; }
        public int Patient_Id { get; set; }

        public DataTable GetAllDoctors()
        {
            string[] paramName = { };
            object[] paramValue = { };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetAllDoctors");
            }
            catch
            {
                return null;
            }
        }

        //usp_GetDoctorDetailsDocId
        public DataTable GetDoctorDetailsDocId(int doctorId)
        {
            string[] paramName = { "@DoctorID" };
            object[] paramValue = { doctorId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDoctorDetailsDocId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetOPDByDoctors(int doctorId)
        {
            string[] paramName = { "@DoctorID" };
            object[] paramValue = { doctorId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetOPDByDoctors");
            }
            catch
            {
                return null;
            }
        }

        public DataTable CheckIfTimeSlotAvailable(string selectedTimeSlot, string opdid, string appntDt)
        {
            string[] paramName = { "@SelectedTimeSlot", "@OPDId" , "@AppointDate"};
            object[] paramValue = { selectedTimeSlot, opdid, appntDt };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_CheckIfTimeSlotAvailable");
            }
            catch
            {
                return null;
            }
        }

        public int SubmitNewAppointment()
        {
            string[] paramName = { "@Speciality",
                                   "@OPDLocation",
                                   "@TimeSlot",
                                   "@Doctor_Id",
                                   "@Patient_Id",
                                   "@AppointDate"

            };
            object[] paramValue = { Speciality,
                                    OPDLocation,
                                    TimeSlot,
                                    Doctor_Id,
                                    Patient_Id,
                                    AppointmentDate
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_SubmitNewAppointment", true);
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetAppointmentByPatientId(int patientId)
        {
            string[] paramName = { "@PatientId"};
            object[] paramValue = { patientId};
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetAppointmentByPatientId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetAppointmentsByDocId(object appntDt, object opd, object status, object patientid)
        {
            string[] paramName = { "@DoctorId", "@AppointmentDt", "@OPD", "@Status", "@PatientId" };
            object[] paramValue = { Doctor_Id, appntDt, opd,status, patientid };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetAppointmentsByDocId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetOPDBookedTimeSlot(string opdid, string appntDate)
        {
            string[] paramName = { "@OPDId", "@AppointDate" };
            object[] paramValue = { opdid, appntDate };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetOPDBookedTimeSlot");
            }
            catch
            {
                return null;
            }
        }

        public DataTable CheckIfAppointmentCompleted()
        {
            string[] paramName = { "@AppointmentId" };
            object[] paramValue = { AppointmentId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_CheckIfAppointmentCompleted");
            }
            catch
            {
                return null;
            }
        }

        public int UpdateAppointmentStatusToCompleted()
        {
            string[] paramName = { "@AppointmentId" };
            object[] paramValue = {  AppointmentId};
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateAppointmentStatusToCompleted", false);
            }
            catch
            {
                return 0;
            }
        }
    }
}