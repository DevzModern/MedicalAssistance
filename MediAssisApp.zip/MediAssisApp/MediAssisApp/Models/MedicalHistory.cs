﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class MedicalHistory
    {
        public int Appointment_Id { get; set; }
        public int MedHistoryId { get; set; }
        public string Condition { get; set; }
        public string Note { get; set; }

        public DataTable GetMedicalHistoryByAppointmentId()
        {
            string[] paramName = { "@Appointment_Id" };
            object[] paramValue = { Appointment_Id };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetMedicalHistoryByAppointmentId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetDiagnosisDetailsByMedHistId()
        {
            string[] paramName = { "@MedHis_Id" };
            object[] paramValue = { MedHistoryId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDiagnosisDetailsByMedHistId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetDiagnosisReportsDetailsByMedHistId()
        {
            string[] paramName = { "@MedHis_Id" };
            object[] paramValue = { MedHistoryId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDiagnosisReportsDetailsByMedHistId");
            }
            catch
            {
                return null;
            }
        }

        // Save to Medical History
        public int SubmitDoctorsPrescription()
        {
            string[] paramName = { "@Appointment_Id",
                                   "@Condition",
                                   "@Note"

            };
            object[] paramValue = { Appointment_Id,
                                    Condition,
                                    Note
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_SubmitDoctorsPrescription", true);
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetPrevMedHistoryByPatientId(int patientId)
        {
            string[] paramName = { "@PatientId" };
            object[] paramValue = { patientId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetPrevMedHistoryByPatientId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable ViewPrevMedHistory1(int patientId)
        {
            string[] paramName = { "@PatientId" };
            object[] paramValue = { patientId };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_ViewPrevMedHistory1");
            }
            catch
            {
                return null;
            }
        }

        public DataTable ViewPrevMedHistory2(int patientId, object medHisId)
        {
            string[] paramName = { "@PatientId", "@MedHisId" };
            object[] paramValue = { patientId , medHisId};
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_ViewPrevMedHistory2");
            }
            catch
            {
                return null;
            }
        }
    }

    public class MedReports
    {
        public string RType { get; set; }
        public string ReportName { get; set; }
        public string AttachmentPath { get; set; }
        public int MedHistId { get; set; }

        public int AddNewReport()
        {
            string[] paramName = { "@RType",
                                   "@ReportName",
                                   "@AttachmentPath",
                                   "@MedHistId"

            };
            object[] paramValue = { RType,
                                    ReportName,
                                    AttachmentPath,
                                    MedHistId
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_AddNewReport", true);
            }
            catch
            {
                return 0;
            }
        }
    }
}