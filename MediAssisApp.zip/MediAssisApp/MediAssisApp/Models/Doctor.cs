﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string Pwd { get; set; }
        public string RegistrationNo { get; set; }
        public string Degree { get; set; }
        public int HospDispID { get; set; }

        public int RegisterDocDetails()
        {
            string[] paramName = { "@DrName",
                                   "@Email",
                                   "@MobileNo",
                                   "@Pwd",
                                   "@RegiNo",
                                   "@DrDegree"

            };
            object[] paramValue = { Name,
                                    Email,
                                    MobileNo,
                                    Pwd,
                                    RegistrationNo,
                                    Degree
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_RegisterDoctor", true);
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetDoctorsByHospDispID()
        {
            string[] paramName = { "@HospDispId" };
            object[] paramValue = { HospDispID };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetDoctorsByHospDispID");
            }
            catch
            {
                return null;
            }
        }
    }
}