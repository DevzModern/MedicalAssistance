﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class MedicineType
    {
        public int MedTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImgPath { get; set; }

        public DataTable GetAllMedicineTypes()
        {
            string[] paramName = {  };
            object[] paramValue = {  };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetAllMedicineTypes");
            }
            catch
            {
                return null;
            }
        }
    }

    public class MedicineDetails
    {
        public int MedicineId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int MedType_Id { get; set; }

        public DataTable GetMedicinesByTypeId()
        {
            string[] paramName = { "@MedTypeId" };
            object[] paramValue = { MedType_Id };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetMedicineByTypeId");
            }
            catch
            {
                return null;
            }
        }
    }
}