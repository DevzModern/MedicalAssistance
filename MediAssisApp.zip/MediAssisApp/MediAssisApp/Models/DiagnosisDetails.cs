﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class DiagnosisDetails
    {
        public int Medicine_Id { get; set; }
        public string Dosage { get; set; }
        public int Quantity { get; set; }
        public int MedHis_Id { get; set; }

        // Add medicine to patient diagnosis
        public int AddMedicineToPatientDiagnosis()
        {
            string[] paramName = { "@Medicine_Id",
                                   "@Dosage",
                                   "@Quantity",
                                   "@MedHis_Id"

            };
            object[] paramValue = { Medicine_Id,
                                    Dosage,
                                    Quantity,
                                    MedHis_Id
                                    
            };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_AddMedicineToPatientDiagnosis", false);
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetMedicineOfPatientDiagnosis()
        {
            string[] paramName = { "@MedHis_Id" };
            object[] paramValue = { MedHis_Id };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetMedicineOfPatientDiagnosis");
            }
            catch
            {
                return null;
            }
        }
    }
}