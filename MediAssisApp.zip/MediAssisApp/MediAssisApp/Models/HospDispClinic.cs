﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace MediAssisApp.Models
{
    public class HospDispClinic
    {
        public int HospDispID { get; set; }
        public string SearchParam { get; set; }

        public DataTable SearchHospDispClinic()
        {
            string[] paramName = { "@SearchParam" };
            object[] paramValue = { SearchParam };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_SearchHospDispClinic");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetHospDetailsByHospId()
        {
            string[] paramName = { "@HospDispId" };
            object[] paramValue = { HospDispID };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetHospDetailsByHospId");
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetHospImagesByHospId()
        {
            string[] paramName = { "@HospDispId" };
            object[] paramValue = { HospDispID };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetHospImagesByHospId");
            }
            catch
            {
                return null;
            }
        }
    }
}