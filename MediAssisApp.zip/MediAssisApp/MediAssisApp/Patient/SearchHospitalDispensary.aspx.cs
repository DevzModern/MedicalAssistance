﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class SearchHospitalDispensary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            pnlSearchResult.Visible = true;
            BindSearchResultToHTMLTable();
        }

        private void BindSearchResultToHTMLTable()
        {
            Models.HospDispClinic objHospDispClinic = new Models.HospDispClinic();
            objHospDispClinic.SearchParam = TextBox3.Text;
            DataTable dt = objHospDispClinic.SearchHospDispClinic();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("<th>");
                html.Append("Book Appointment");
                html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    html.Append("<td>");

                    html.Append("<a href=\"SearchSelectDoctor.aspx?HospDispId=" + row["HospDispId"] + "\"><input type=\"button\" title=\"Schedule appointment\" value=\"Schedule appointment\" /></a>");
                    //html.Append("<a href=\"DiagnosisDetails.aspx?AppointmentId=" + row["Appointment Id#"] + "\">Details</a>");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}