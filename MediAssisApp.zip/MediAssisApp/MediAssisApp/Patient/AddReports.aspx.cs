﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace MediAssisApp.Patient
{
    public partial class AddReports : System.Web.UI.Page
    {
        Models.MedReports objMedReports = new Models.MedReports();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "close", "<script language=javascript>self.close();</script>");

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            objMedReports.RType = ddlRType.SelectedValue;
            objMedReports.ReportName = txtRName.Text;
            objMedReports.MedHistId = Convert.ToInt32(Session["MedHistoryIdToUpdate"]); //75864; //TODO: Pass med hist id

            UploadProjectDocument();

            objMedReports.AddNewReport();
            lblMsg.Text = "Report saved..";

            btnSave.Attributes.Add("onclick", "window.opener.location.reload();");
        }

        private void UploadProjectDocument()
        {
            if (FUploadProjDocsSyn.HasFile)
            {
                string filename = Path.GetFileName(FUploadProjDocsSyn.PostedFile.FileName);
                FUploadProjDocsSyn.SaveAs(MapPath("~/Patient/Reports/") + filename);

                objMedReports.AttachmentPath = ("~/Patient/Reports/") + filename;
            }
        }
    }
}