﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;

namespace MediAssisApp.Patient
{
    public partial class AddEditPolicy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PopuldatePolicyDetails();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            PatientMediclaimPolicy objPatientMediclaimPolicy = new PatientMediclaimPolicy();
            objPatientMediclaimPolicy.MediclaimPolicyNo = txtPolicyNo.Text;
            objPatientMediclaimPolicy.SumAssured = txtSumAssured.Text;
            objPatientMediclaimPolicy.Duration = txtDuration.Text;
            objPatientMediclaimPolicy.Company = txtCompany.Text;
            objPatientMediclaimPolicy.Patient_Id = Convert.ToInt32(Session["PatientId"]);

            //objPatientMediclaimPolicy.InsertMediclaimPolicy();
            lblMsg.Text = "Policy details Updated!";
            lblMsg.ForeColor = System.Drawing.Color.Green;

            btnSave.Attributes.Add("onclick", "window.opener.location.reload();");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "close", "<script language=javascript>self.close();</script>");
        }

        private void PopuldatePolicyDetails() 
        {
            txtPolicyNo.Text = "1";
            txtSumAssured.Text = "2";
        }
    }
}