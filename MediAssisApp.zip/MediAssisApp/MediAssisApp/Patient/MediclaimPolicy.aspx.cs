﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class MediclaimPolicy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            {
                BindMediPoliciesToHTMLTable();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            PatientMediclaimPolicy objPatientMediclaimPolicy = new PatientMediclaimPolicy();
            objPatientMediclaimPolicy.MediclaimPolicyNo = txtPolicyNo.Text;
            objPatientMediclaimPolicy.SumAssured = txtSumAssured.Text;
            objPatientMediclaimPolicy.Duration = txtDuration.Text;
            objPatientMediclaimPolicy.Company = txtCompany.Text;
            objPatientMediclaimPolicy.Patient_Id = Convert.ToInt32(Session["PatientId"]);

            objPatientMediclaimPolicy.InsertMediclaimPolicy();
            lblMsg.Text = "Policy details saved!";
            lblMsg.ForeColor = System.Drawing.Color.Green;

            //BindMediPoliciesToHTMLTable();
        }

        private void BindMediPoliciesToHTMLTable()
        {
            Models.Patient objPatient = new Models.Patient();
            string patientId = Convert.ToString(Session["PatientId"]);

            DataTable dt = objPatient.GetMediPoliciesByPatientId(patientId);

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    html.Append("<td>");
                    //html.Append("<a href=\"AddEditPolicy.aspx?AppointmentId=" + row["PolicyRecordId"] + "\">Details</a>");
                    html.Append("<input type=\"submit\" title=\"Edit policy\" value=\"Edit\" onclick=\"openAddEditPopup(" + row["PolicyRecordId"] + ");\" />");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}