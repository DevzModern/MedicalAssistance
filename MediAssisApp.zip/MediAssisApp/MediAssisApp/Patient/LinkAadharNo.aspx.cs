﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace MediAssisApp.Patient
{
    public partial class LinkAadharNo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CheckIfAadharLinked();
            }
        }

        private void CheckIfAadharLinked()
        {
            Models.Patient p = new Models.Patient();
            p.PatientId = Convert.ToInt32(Session["PatientId"]);
            DataTable dt = p.CheckIfAadharisLinked();
            if (dt != null)
            {
                txtPatID.Text = Convert.ToString(Session["PatientId"]);

                object aadharno = dt.Rows[0]["Aadhar_Info_Id"];
                if (aadharno == DBNull.Value)
                {
                    lblLoginStatus.Text = "Aadhar is not linked!";
                    lblLoginStatus.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    txtAadhar.Text = (string)dt.Rows[0]["Aadhar_Info_Id"];
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.Patient p = new Models.Patient();
            p.PatientId = Convert.ToInt32(Session["PatientId"]);
            p.AadharNo = txtAadhar.Text;

            p.UpdateAadhar();
            lblLoginStatus.Text = "Aadhar Updated Successfully!";
            lblLoginStatus.ForeColor = System.Drawing.Color.Green;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtAadhar.Text = "";
            txtPatID.Text = "";
            lblLoginStatus.Text = "";
        }
    }
}