﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class AppointmentHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //int fdId = Convert.ToInt32(Session["FoodDonorId"]);
                BindAllAppointmentsToHTMLTable();
            }
        }

        private void BindAllAppointmentsToHTMLTable()
        {
            Models.Appointment objAppointment = new Models.Appointment();
            int patientId = Convert.ToInt32(Session["PatientId"]);

            DataTable dt = objAppointment.GetAppointmentByPatientId(patientId);

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    html.Append("<td>");
                    html.Append("<a href=\"DiagnosisDetails.aspx?AppointmentId=" + row["Appointment Id#"] + "\">Details</a>");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}