﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class NewAppointment : System.Web.UI.Page
    {
        Appointment objAppointment = new Appointment();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindDoctorsDDL();

                if (Request.QueryString["DoctorId"] != null)
                {
                    PopulateSelectedDoctorDetails();
                }
            }
        }

        private void BindDoctorsDDL()
        {
            DataTable dtDocs = objAppointment.GetAllDoctors();

            ddlDoctors.DataSource = dtDocs;
            ddlDoctors.DataTextField = "DrName";
            ddlDoctors.DataValueField = "DoctorId";
            ddlDoctors.DataBind();

            ddlDoctors.Items.Insert(0, new ListItem("--Select Doctor--", "0"));

        }

        private void PopulateSelectedDoctorDetails()
        {
            DataTable dt1= objAppointment.GetDoctorDetailsDocId(Convert.ToInt32(Request.QueryString["DoctorId"]));
            if (dt1 != null && dt1.Rows.Count > 0)
            {
                ddlDoctors.SelectedValue = Convert.ToString(dt1.Rows[0]["DoctorId"]);
                ddlSpeciality.SelectedValue = (string)dt1.Rows[0]["Speciality"];
            }
            PopulateOPDDDLByDoctor(Convert.ToInt32(Request.QueryString["DoctorId"]));
        }

        private void PopulateOPDDDLByDoctor(int docid)
        {
            DataTable dtOPD = objAppointment.GetOPDByDoctors(docid);

            if (dtOPD != null && dtOPD.Rows.Count > 0)
            {
                txtOPD.Text = Convert.ToString(dtOPD.Rows[0]["OPDId"]);
            }
            else
            {
                txtOPD.Text = "";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            objAppointment.Speciality = ddlSpeciality.SelectedValue;
            objAppointment.Doctor_Id = Convert.ToInt32(ddlDoctors.SelectedItem.Value);
            objAppointment.Patient_Id = Convert.ToInt32(Session["PatientId"]);
            objAppointment.OPDLocation = txtOPD.Text;
            objAppointment.TimeSlot = ddlTime.SelectedValue;

            objAppointment.AppointmentDate = Convert.ToDateTime(txtAppointmentDt.Text).ToString("yyyy-MM-dd");
            objAppointment.SubmitNewAppointment();
            lblStatus.Text = "Your Appointment is confirmed!";
            lblStatus.ForeColor = System.Drawing.Color.Green;

            lblTimeSlotStatus.Visible = false;

            BindOPDAvailabilityStatusToHTMLTable(txtOPD.Text);
        }

        protected void ddlDoctors_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateOPDDDLByDoctor(Convert.ToInt32(ddlDoctors.SelectedItem.Value));

            if (!string.IsNullOrEmpty(txtOPD.Text))
            {
                BindOPDAvailabilityStatusToHTMLTable(txtOPD.Text);
            }
        }

        private void BindOPDAvailabilityStatusToHTMLTable(string opd)
        {
            Models.Appointment objAppointment = new Models.Appointment();
            DataTable dt = objAppointment.GetOPDBookedTimeSlot(opd, Convert.ToDateTime(txtAppointmentDt.Text).ToString("yyyy-MM-dd"));


            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"3\">");
                html.Append("No Booking Done Yet!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void ddlTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTimeSlot = ddlTime.SelectedValue;

            if (!string.IsNullOrEmpty(txtOPD.Text))
            {
                DataTable dtTimeSlots = objAppointment.CheckIfTimeSlotAvailable(selectedTimeSlot, txtOPD.Text,
                    Convert.ToDateTime(txtAppointmentDt.Text).ToString("yyyy-MM-dd"));
                if (dtTimeSlots != null && dtTimeSlots.Rows.Count > 0)
                {
                    lblTimeSlotStatus.Text = "Not Available";
                    lblTimeSlotStatus.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    btnSubmit.Enabled = true;
                    lblTimeSlotStatus.Text = "Available";
                    lblTimeSlotStatus.ForeColor = System.Drawing.Color.Green;
                }

                if (!string.IsNullOrEmpty(txtOPD.Text))
                {
                    BindOPDAvailabilityStatusToHTMLTable(txtOPD.Text);
                }
            }
            else {
                lblTimeSlotStatus.Text = "Please select Doctor!";
                lblTimeSlotStatus.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}