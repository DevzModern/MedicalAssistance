﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TestLib;

namespace MediAssisApp.Patient
{
    public partial class PatientMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Dummy obj = new Dummy();
            if (!obj.ValidSessionKey())
            {
                Response.Redirect(obj.ReturnValidURL02());
            }
            else
            {
                if (Session["PatientId"] == null)
                {
                    Response.Redirect(obj.ReturnValidURL02());
                }
            }
        }
    }
}