﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class SearchSelectDoctor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            {
                pnlOverview.Visible = true;
                int hospDispId = Convert.ToInt32(Request["HospDispId"]);
                PopulateHospDetails(hospDispId);

                BindDoctorsOfSpecififcHospiOrDespToHTMLTable(hospDispId);
            }
        }

        private void PopulateHospDetails(int hospdispId)
        {
            Models.HospDispClinic objHospDispClinic = new Models.HospDispClinic();
            objHospDispClinic.HospDispID = hospdispId;

            DataTable dt1 = objHospDispClinic.GetHospDetailsByHospId();
            if (dt1 != null && dt1.Rows.Count > 0)
            {
                lblHospDispName1.Text = (string)dt1.Rows[0]["Name"];
                lblHospDispName2.Text = (string)dt1.Rows[0]["Name"];
                lblHospDispName3.Text = (string)dt1.Rows[0]["Name"];
                lblLocation.Text = (string)dt1.Rows[0]["Location"];
                lblAddress.Text = (string)dt1.Rows[0]["Address"];
                lblAbout.Text = (string)dt1.Rows[0]["About"];
                lblServices.Text = (string)dt1.Rows[0]["Services"];
                lblTiming.Text = (string)dt1.Rows[0]["Availability"];
            }
            DataTable dt2 = objHospDispClinic.GetHospImagesByHospId();
        }

        private void BindDoctorsOfSpecififcHospiOrDespToHTMLTable(int hospDispId)
        {
            // get doct by hospDispId from DoctorDetails
            Models.Doctor objDoctor = new Models.Doctor();
            objDoctor.HospDispID = Convert.ToInt32(Request.QueryString["HospDispId"]);
            DataTable dt = objDoctor.GetDoctorsByHospDispID();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered\"");

                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    html.Append("<td style=\"width: 20%\">");
                    html.Append("<img ID=\"Image2\" src=\"" + row["ProfileImage"] + "\" Height=\"100px\" Width=\"100px\"/>");
                    html.Append("</td>");

                    html.Append("<td style=\"width: 60%\">");
                    html.Append("<h4>Dr " + row["DrName"] + "</h4><br />" + row["DrDegree"] + "<br />" + row["Expi"] + " experience");
                    html.Append("</td>");


                    html.Append("<td style=\"width: 20%\">");
                    html.Append(row["ConsultCharges"] + "<br />" + row["Availability"] + "<br />");
                    html.Append("<a href=\"NewAppointment.aspx?DoctorId=" + row["DoctorId"] + "\"><input type=\"button\" class=\"btn btn-primary\" title=\"Book Appointment\" value=\"Book Appointment\" /></a>");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void btnGetAppointment_Click(object sender, EventArgs e)
        {
            // Pass above selected doctor id to NewAppointment pg
            Response.Redirect("NewAppointment.aspx?DoctorId=");
        }

        protected void lnkbtnOverview_Click(object sender, EventArgs e)
        {
            pnlOverview.Visible = true;
            pnlDoctors.Visible = false;
        }

        protected void lnkbtnDoctors_Click(object sender, EventArgs e)
        {
            pnlDoctors.Visible = true;
            pnlOverview.Visible = false;
        }
    }
}