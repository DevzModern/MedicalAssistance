﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;
using System.Data;
using System.Text;

namespace MediAssisApp.Patient
{
    public partial class DiagnosisDetails : System.Web.UI.Page
    {
        Models.MedicalHistory objMedicalHistory = new Models.MedicalHistory();
        private static int medHistoryId = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            {
                PopulateMedicalHistoryDetails();
                BindDiagnosisReportsDetailsToHTMLTable();
            }
        }

        private void PopulateMedicalHistoryDetails()
        {
            objMedicalHistory.Appointment_Id = Convert.ToInt32(Request.QueryString["AppointmentId"]);
            DataTable dtMedHistory = objMedicalHistory.GetMedicalHistoryByAppointmentId();

            medHistoryId = 0;

            if (dtMedHistory != null && dtMedHistory.Rows.Count > 0)
            {
                lblDOV.Text = Convert.ToString(dtMedHistory.Rows[0]["DateOfVisit"]);
                lblCondition.Text = Convert.ToString(dtMedHistory.Rows[0]["Condition"]);
                lblNote.Text = Convert.ToString(dtMedHistory.Rows[0]["DescriptionNote"]);

                medHistoryId = objMedicalHistory.MedHistoryId = Convert.ToInt32(dtMedHistory.Rows[0]["MedHisId"]);

                Session["MedHistoryIdToUpdate"] = medHistoryId;
            }
            else
            {
                lblDOV.Text = "Not yet attended by Doctor";
                lblCondition.Text = "Not yet attended by Doctor";
                lblNote.Text = "Not yet attended by Doctor";
            }
        }

        protected void btnShowMedi_Click(object sender, EventArgs e)
        {
            pnlMedi.Visible = true;
            pnlReports.Visible = false;

            BindDiagnosisDetailsToHTMLTable();
        }

        protected void btnShowReports_Click(object sender, EventArgs e)
        {
            pnlMedi.Visible = false;
            pnlReports.Visible = true;

            //BindDiagnosisReportsDetailsToHTMLTable();
        }

        private void BindDiagnosisDetailsToHTMLTable()
        {
            objMedicalHistory.MedHistoryId = medHistoryId;
            DataTable dt = objMedicalHistory.GetDiagnosisDetailsByMedHistId();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                //html.Append("<th>");
                //html.Append("Action");
                //html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    //html.Append("<td>");
                    //html.Append("<a href=\"DiagnosisDetails.aspx?AppointmentId=" + row["Appointment Id#"] + "\">Details</a>");
                    //html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        private void BindDiagnosisReportsDetailsToHTMLTable()
        {
            objMedicalHistory.MedHistoryId = medHistoryId;
            DataTable dt = objMedicalHistory.GetDiagnosisReportsDetailsByMedHistId();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                //html.Append("<th>");
                //html.Append("Action");
                //html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        if (column.ColumnName != "Download link")
                        {
                            html.Append("<td>");
                            html.Append(row[column.ColumnName]);
                            html.Append("</td>");
                        }
                    }

                    html.Append("<td>");
                    html.Append("<a href=\"DownloadReport.aspx?AttachmentPath=" + row["Download link"] + "\">Download</a>");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder2.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}