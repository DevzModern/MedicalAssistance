﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;

namespace MediAssisApp.Patient
{
    public partial class DownloadReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Download();
        }

        private void Download()
        {
            string docPath = (string)Request.QueryString["AttachmentPath"];
            Response.ContentType = ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(docPath));
            Response.WriteFile("../Patient/Reports/" + Path.GetFileName(docPath));
            Response.End();

        }
    }
}