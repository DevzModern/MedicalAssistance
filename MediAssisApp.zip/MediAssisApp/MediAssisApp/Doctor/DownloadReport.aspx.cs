﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;

namespace MediAssisApp.Doctor
{
    public partial class DownloadReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Download();
        }

        private void Download()
        {
            int docId = Convert.ToInt32(Request["DocId"]);
            //models.ProjectDocuments objProjDoc = new models.ProjectDocuments();
            //DataTable dt = objProjDoc.GetDocDetailsByDocId(docId);

            //if (dt.Rows.Count > 0)
            //{
            //    string docPath = Convert.ToString(dt.Rows[0]["DocPath"]);
            //    Response.ContentType = ContentType;
            //    Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(docPath));
            //    Response.WriteFile("../Doctor/Reports/" + Path.GetFileName(docPath));
            //    Response.End();
            //}
        }
    }
}