﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Doctor
{
    public partial class Appointments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["DoctorId"] != null)
            {
                if (!Page.IsPostBack)
                {
                    BindAppointmentsByDocIdToHTMLTable();
                }
            }
            else
            {
                Response.Redirect("../DoctorLogin.aspx");
            }
        }

        private void BindAppointmentsByDocIdToHTMLTable()
        {
            Models.Appointment objAppointment = new Models.Appointment();
            objAppointment.Doctor_Id = Convert.ToInt32(Session["DoctorId"]);

            object adt = (txtAppointmentDt.Text == string.Empty) ? DBNull.Value : (object)txtAppointmentDt.Text;
            object opd = (ddlOPD.SelectedValue == "-1") ? DBNull.Value : (object)ddlOPD.SelectedValue;
            object status = (ddlStatus.SelectedValue == "-1") ? DBNull.Value : (object)ddlStatus.SelectedValue;
            object patientid = (txtPAtientID.Text == string.Empty) ? DBNull.Value : (object)txtPAtientID.Text;

            DataTable dt = objAppointment.GetAppointmentsByDocId(adt, opd,status, patientid);

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                        html.Append("<th>");
                        html.Append(column.ColumnName);
                        html.Append("</th>");
                }

                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                bool isRequestFound = false;

                foreach (DataRow row in dt.Rows)
                {
                    DateTime creationTime = Convert.ToDateTime(row["Appointment Date"]);
                    if (creationTime.Date >= DateTime.Now.Date)
                    {
                        html.Append("<tr>");
                        foreach (DataColumn column in dt.Columns)
                        {
                            if (column.ColumnName == "Patient Photo")
                            {
                                html.Append("<td>");
                                html.Append("<img class=\"img-fluid rounded mb-4\" src=\"" + row[column.ColumnName] + "\" alt=\"\" style=\"height: 100px;\" />");
                                html.Append("</td>");
                            }
                            else
                            {
                                html.Append("<td>");
                                html.Append(row[column.ColumnName]);
                                html.Append("</td>");
                            }
                        }

                        html.Append("<td>");
                        // TODO: Disable Attend link for Completed requests
                        html.Append("<a href=\"AttendAppointment.aspx?AppointmentId=" + row["Appointment Id#"] + "&PatientId=" + row["Patient_Id"] + "\">Attend</a>");
                        html.Append("</td>");

                        html.Append("</tr>");
                        isRequestFound = true;
                    }
                }

                if (!isRequestFound)
                {
                    html.Append("<tr>");


                    html.Append("<td colspan=\"8\">");
                    html.Append("No appointments found!");
                    html.Append("</td>");

                    html.Append("</tr>");
                }
                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"9\">");
                html.Append("No appointments found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindAppointmentsByDocIdToHTMLTable();
        }
    }
}