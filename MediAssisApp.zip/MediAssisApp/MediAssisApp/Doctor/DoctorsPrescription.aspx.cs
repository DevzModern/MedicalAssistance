﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;
using System.Data;
using System.Text;

namespace MediAssisApp.Doctor
{
    public partial class DoctorsPrescription : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CheckIfAppointmentCompleted();
            }
        }

        private void CheckIfAppointmentCompleted()
        {
            Models.Appointment objApp = new Appointment();
            objApp.AppointmentId = Convert.ToInt32(Request.QueryString["AppointmentIdToUpdate"]);

            DataTable dtTemp = objApp.CheckIfAppointmentCompleted();

            if (dtTemp != null && dtTemp.Rows.Count > 0)
            {
                btnSubmit.Enabled = false;
                txtCondition.Text = Convert.ToString(dtTemp.Rows[0]["Condition"]);
                txtNote.Text = Convert.ToString(dtTemp.Rows[0]["DescriptionNote"]);

                BindMedicinesToHTMLTable();
                BindMedicalReportsToHTMLTable();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            MedicalHistory objMedicalHistory = new MedicalHistory();
            objMedicalHistory.Condition = txtCondition.Text;
            objMedicalHistory.Note = txtNote.Text;
            objMedicalHistory.Appointment_Id = Convert.ToInt32(Request.QueryString["AppointmentIdToUpdate"]);

            int medHistoryId = objMedicalHistory.SubmitDoctorsPrescription();
            Session["MedHistoryIdToUpdate"] = medHistoryId;

            lblStatus.Text = "Prescription is updated!";
            lblStatus.ForeColor = System.Drawing.Color.Green;
            btnAddMedi.Enabled = true;
            btnUploadReports.Enabled = true;
            btnMarkComplete.Enabled = true;
        }

        protected void btnAddMedi_Click(object sender, EventArgs e)
        {
            int medHistoryID = Convert.ToInt32(Session["MedHistoryIdToUpdate"]);

            // update medicine details in tblPatientDiagnosisDetails with MedHis_Id
            DiagnosisDetails objDiagnosisDetails = new DiagnosisDetails();
            objDiagnosisDetails.Medicine_Id = Convert.ToInt32(txtMedicineName.Text);
            objDiagnosisDetails.Dosage = txtDosage.Text;
            objDiagnosisDetails.Quantity = Convert.ToInt32(ddlQuanity.SelectedValue);
            objDiagnosisDetails.MedHis_Id = medHistoryID;

            objDiagnosisDetails.AddMedicineToPatientDiagnosis();

            BindMedicinesToHTMLTable();
        }

        private void BindMedicinesToHTMLTable()
        {
            int medHistoryID = Convert.ToInt32(Session["MedHistoryIdToUpdate"]);

            DiagnosisDetails objDiagnosisDetails = new DiagnosisDetails();
            objDiagnosisDetails.MedHis_Id = medHistoryID;

            DataTable dt = objDiagnosisDetails.GetMedicineOfPatientDiagnosis();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }

                    html.Append("</tr>");
                }
                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"5\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void btnUploadReports_Click(object sender, EventArgs e)
        {
            int medHistoryID = Convert.ToInt32(Session["MedHistoryIdToUpdate"]);

            // update reports details in tblPatientDiagnosisDetails with MedHis_Id

            BindMedicalReportsToHTMLTable();
        }

        private void BindMedicalReportsToHTMLTable()
        {

        }

        protected void btnMarkComplete_Click(object sender, EventArgs e)
        {
            // Change status of aapointment to completed
            Appointment objAppointment = new Appointment();
            objAppointment.AppointmentId = Convert.ToInt32(Request.QueryString["AppointmentIdToUpdate"]);

            objAppointment.UpdateAppointmentStatusToCompleted();

            lblStatus.Text = "Appointment is marked completed";
        }

    }
}