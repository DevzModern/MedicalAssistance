﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Doctor
{
    public partial class DetailedReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindMediHistoryToHTMLTable();
            }
        }

        private void BindMediHistoryToHTMLTable()
        {
            int patienid = Convert.ToInt32(Request.QueryString["PatientId"]);
            //[usp_ViewPrevMedHistory2]
            Models.MedicalHistory objMedicalHistory = new Models.MedicalHistory();
            object medHidID = Convert.ToInt32(Request.QueryString["MedHisId"]);

            DataTable dt = objMedicalHistory.ViewPrevMedHistory2(patienid, medHidID);

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered\"");

                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    html.Append("<td style=\"width: 20%\">");
                    html.Append(row["AppointmentDate"] + "<br /><br/>");
                    html.Append("<img ID=\"Image2\" src=\"../img/Calender.png\" Height=\"70px\" Width=\"70px\"/>");


                    html.Append("</td>");

                    html.Append("<td style=\"width: 40%\">");
                    html.Append("<h4>Condition: " + row["Condition"] + "</h4><br /> Prescription Note: <br/>" + row["DescriptionNote"] + "<br />" + row["DescriptionNote"] + " experience");
                    html.Append("</td>");


                    html.Append("<td>Medicine Details:<br/>");
                    html.Append(row["Name"] + "<br />" + row["Dosage"] + "<br />" + row["Description"] + "<br /></td>");
                    //html.Append("<a href=\"NewAppointment.aspx?DoctorId=" + row["DoctorId"] + "\"><input type=\"button\" class=\"btn btn-primary\" title=\"Book Appointment\" value=\"Book Appointment\" /></a>");
                    html.Append("</td>");

                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No data found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder3.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}