﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace MediAssisApp.Doctor
{
    public partial class PatientHealthDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            pnlPatientHealthDetails.Visible = true;
            PopulatePatientDetails();
            PopulateAadharDetails();
        }

        private void PopulatePatientDetails()
        {
            Models.Patient objPatient = new Models.Patient();
            DataTable dtPatientDetails = objPatient.GetPtientHealthDetailsByAadharNo(txtAadharNo.Text);

            DataTable dtAadharDetails = objPatient.GetDetailsByAadharNo(txtAadharNo.Text);

            if (dtPatientDetails != null && dtPatientDetails.Rows.Count > 0)
            {
                lblPatId.Text = Convert.ToString(dtPatientDetails.Rows[0]["PatientId"]);
                lblName.Text = Convert.ToString(dtPatientDetails.Rows[0]["Name"]);
                lblAge.Text = Convert.ToString(dtPatientDetails.Rows[0]["Age"]);
                lblBG.Text = Convert.ToString(dtPatientDetails.Rows[0]["BloodGroup"]);
                lblAadhar.Text = Convert.ToString(dtPatientDetails.Rows[0]["Aadhar_Info_Id"]);
                lblEmail.Text = Convert.ToString(dtPatientDetails.Rows[0]["Email"]);
                lblContact.Text = Convert.ToString(dtPatientDetails.Rows[0]["MobileNo"]);
                lblAddress.Text = Convert.ToString(dtPatientDetails.Rows[0]["Address"]);

                // Health details
                lblHealthIssues.Text = Convert.ToString(dtPatientDetails.Rows[0]["HealthIssues"]);
                lblDiseases.Text = Convert.ToString(dtPatientDetails.Rows[0]["Diseases"]);
                lblAllergies.Text = Convert.ToString(dtPatientDetails.Rows[0]["Allergies"]);
                lblOther.Text = Convert.ToString(dtPatientDetails.Rows[0]["Other"]);

            }

            if (dtAadharDetails != null && dtAadharDetails.Rows.Count > 0)
            {
                lblAName.Text = Convert.ToString(dtAadharDetails.Rows[0]["Name"]);
                lblADob.Text = Convert.ToString(dtAadharDetails.Rows[0]["DOB"]);
                lblAAdress.Text = Convert.ToString(dtAadharDetails.Rows[0]["Address"]);
                lblAGender.Text = Convert.ToString(dtAadharDetails.Rows[0]["Gender"]);
            }
        }

        private void PopulateAadharDetails()
        { 
            //[usp_GetDetailsByAadharNo]
        }

        protected void btnMedHistory_Click(object sender, EventArgs e)
        {
            Response.Redirect("PreviousMedicalRecords.aspx?PatientId=" + lblPatId.Text);
        }
    }
}