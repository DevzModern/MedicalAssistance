﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MediAssisApp.Models;

namespace MediAssisApp.Doctor
{
    public partial class AttendAppointment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                PopulatePatientDetails();
            }
        }

        private void PopulatePatientDetails()
        {
            Models.Patient objPatient = new Models.Patient();
            objPatient.PatientId = Convert.ToInt32(Request.QueryString["PatientId"]);
            DataTable dtPatientDetails = objPatient.GetDetailsByPatientId();

            if (dtPatientDetails != null && dtPatientDetails.Rows.Count > 0)
            {
                lblPatId.Text = Convert.ToString(dtPatientDetails.Rows[0]["PatientId"]);
                lblName.Text = Convert.ToString(dtPatientDetails.Rows[0]["Name"]);
                lblAge.Text = Convert.ToString(dtPatientDetails.Rows[0]["Age"]);
                lblBG.Text = Convert.ToString(dtPatientDetails.Rows[0]["BloodGroup"]);
                lblAadhar.Text = Convert.ToString(dtPatientDetails.Rows[0]["Aadhar_Info_Id"]);
            }

            Session["PatientID_PrevHist"] = Convert.ToInt32(Request.QueryString["PatientId"]); 
        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            string appointmentIdToUpdate = Convert.ToString(Request.QueryString["AppointmentId"]); ;
            Response.Redirect("DoctorsPrescription.aspx?AppointmentIdToUpdate=" + appointmentIdToUpdate);
        }

        protected void btnDiagnoHistory_Click(object sender, EventArgs e)
        {
            //TODO: Display prev medicine history
            //pnlPrescriptionHistory.Visible = true;
        }
    }
}