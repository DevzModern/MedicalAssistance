﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace MediAssisApp.Doctor
{
    public partial class PreviousMedicalRecords : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["DoctorId"] != null)
            {
                //if (!Page.IsPostBack)
                {
                    BindPrevMedHistoryToHTMLTable();
                }
                if (Request["MedHisId"] != null)
                {
                    pnlPrescriptionHistory.Visible = true;
                    PopulateMedicalHistoryByMedHistId(0);
                }
            }
            else
            {
                Response.Redirect("../DoctorLogin.aspx");
            }
        }

        private void BindPrevMedHistoryToHTMLTable()
        {
            Models.MedicalHistory objMedicalHistory = new Models.MedicalHistory();
            DataTable dt = objMedicalHistory.GetPrevMedHistoryByPatientId(Convert.ToInt32(Request["PatientId"]));

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                html.Append("<table class=\"table table-bordered table-hover\"");
                html.Append("<thead><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }

                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr></thead>");
                html.Append("<tbody>");
                //bool isRequestFound = false;

                foreach (DataRow row in dt.Rows)
                {

                    html.Append("<tr>");
                    foreach (DataColumn column in dt.Columns)
                    {
                        if (column.ColumnName == "Patient Photo")
                        {
                            html.Append("<td>");
                            html.Append("<img class=\"img-fluid rounded mb-4\" src=\"" + row[column.ColumnName] + "\" alt=\"\" style=\"height: 100px;\" />");
                            html.Append("</td>");
                        }
                        else
                        {
                            html.Append("<td>");
                            html.Append(row[column.ColumnName]);
                            html.Append("</td>");
                        }
                    }

                    html.Append("<td>");
                    //html.Append("<a href=\"PreviousMedicalRecords.aspx?MedHisId=" + row["MedHisId"] + "&PatientId=" + Request["PatientId"] + "\">Detailed Report</a>");
                    html.Append("<input type=\"submit\" title=\"Detailed Report\" value=\"Detailed Report\" onclick=\"openAddEditPopup(" + row["MedHisId"] + ',' + Request["PatientId"] + ");\" />");

                    html.Append("</td>");
                    html.Append("</tr>");
                }

                html.Append("</tbody>");
                html.Append("</table>");
            }
            else
            {
                //No data found..
                html.Append("<table class=\"table table-bordered\">");
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("<th>");
                html.Append("Action");
                html.Append("</th>");

                html.Append("</tr>");

                html.Append("<tr>");


                html.Append("<td colspan=\"8\">");
                html.Append("No appointments found!");
                html.Append("</td>");

                html.Append("</tr>");
                html.Append("</table>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        private void PopulateMedicalHistoryByMedHistId(int medHistId)
        { 
        
        }

        protected void btnDiagnose_Click(object sender, EventArgs e)
        {
            // TODO: As this patient os treated without appointment
            // Make entry into AppointmentDetails Table with type 'Unschduled' and pass that in query string
            //AttendAppointment.aspx?AppointmentId=56562&PatientId=56871

            Response.Redirect("DoctorsPrescription.aspx?AppointmentIdToUpdate=56562");
        }
    }
}