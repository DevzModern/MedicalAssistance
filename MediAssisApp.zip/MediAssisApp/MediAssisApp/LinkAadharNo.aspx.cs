﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace MediAssisApp
{
    public partial class LinkAadharNo : System.Web.UI.Page
    {
        Models.Patient objP = new Models.Patient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {   
            string aadharNo = txtAadharNo.Text;
            DataTable dt = objP.GetDetailsByAadharNo(aadharNo);

            if (dt != null && dt.Rows.Count > 0)
            {
                lblName.Text = (string)dt.Rows[0]["Name"];

                lblAddress.Text = (string)dt.Rows[0]["Address"];
                lblGender.Text = (string)dt.Rows[0]["Gender"];
                lblDOB.Text = (string)dt.Rows[0]["DOB"];

                lblLinkStatus.Text = "Find below Aadhar Details! ";
                lblLinkStatus.ForeColor = System.Drawing.Color.Green;

                pnlAadharDetails.Visible = true;
            }
            else
            {
                lblLinkStatus.Text = "Aadhar number not found! ";
                lblLinkStatus.ForeColor = System.Drawing.Color.Red;

                pnlAadharDetails.Visible = false;
            }
        }

        protected void btnLink_Click(object sender, EventArgs e)
        {
            string aadharNoToLink = txtAadharNo.Text;
            int patientId = Convert.ToInt32(Session["RegisteredPatientID"]);

            int linkResult = objP.LinkAadharNo(patientId, aadharNoToLink);
            if (linkResult == 0)
            {
                lblLinkStatus.Text = "Aadhar number is linked! " +
                                        "<a href=\"PatientLogin.aspx\">Click Here</a> To Login";
                lblLinkStatus.ForeColor = System.Drawing.Color.Green;
            }
        }
    }
}