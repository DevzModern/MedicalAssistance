﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using TestLib;

namespace MediAssisApp
{
    public partial class PatientLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPwd.Text;

            DataTable userDT = Models.LoginDetails.ValidatePatientCredentials(email, password);
            if (userDT != null && userDT.Rows.Count == 0)
            {
                lblLoginStatus.Text = "Wrong username or password";
                lblLoginStatus.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                Dummy obj = new Dummy();
                if (obj.TestMethod())
                {
                    Session["PatientId"] = Convert.ToString(userDT.Rows[0]["PatientId"]);

                    Response.Redirect(obj.ReturnValidURL01());
                }
                else
                {
                    Models.LoginDetails.LicenseExpired();
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegisterPatient.aspx");
        }
    }
}