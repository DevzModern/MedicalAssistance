﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MediAssisApp.Models;
using System.Data;
using System.Text;

namespace MediAssisApp.Chemist
{
    public partial class Medicines : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindMedicineTypes();
            }
        }

        private void BindMedicineTypes()
        {
            MedicineType objMedicineType = new MedicineType();
            DataTable dt = objMedicineType.GetAllMedicineTypes();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<div class=\"col-lg-4 col-sm-6 portfolio-item\"><div class=\"card h-100\">");
                    html.Append("<a href=\"MedicineByType.aspx?TypeId=" + row["MedTypeId"] + "\"><img class=\"card-img-top\" src=\"" + row["TypeImg"] + "\" alt=\"\"></a>");

                    html.Append("<div class=\"card-body\"><h4 class=\"card-title\">");
                    html.Append("<a href=\"#\">" + row["Type"] + "</a>");
                    html.Append("</h4><p class=\"card-text\">" + row["Description"] + "</p>");
                    html.Append("</div></div></div>");

                }
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("MedicineSearchResult.aspx");
        }
    }
}