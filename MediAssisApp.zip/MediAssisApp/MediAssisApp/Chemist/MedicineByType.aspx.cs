﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using MediAssisApp.Models;

namespace MediAssisApp.Chemist
{
    public partial class MedicineByType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindMedicineByTypeId();
            }
        }

        private void BindMedicineByTypeId()
        {
            Models.MedicineDetails objMedicineType = new Models.MedicineDetails();
            objMedicineType.MedType_Id = Convert.ToInt32( Request.QueryString["TypeId"]);
            DataTable dt = objMedicineType.GetMedicinesByTypeId();

            StringBuilder html = new StringBuilder();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<div class=\"col-lg-4 col-sm-6 portfolio-item\"><div class=\"card h-100\">");
                    html.Append("<a href=\"MedicineDetails.aspx?TypeId=" + row["MedicineId"] + "\"><img class=\"card-img-top\" src=\"" + row["ImgPath"] + "\" alt=\"\"></a>");

                    html.Append("<div class=\"card-body\"><h4 class=\"card-title\">");
                    html.Append("<a href=\"#\">" + row["Name"] + "</a>");
                    html.Append("</h4><p class=\"card-text\">" + row["Description"] + "</p>");
                    html.Append("</div></div></div>");

                }
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}