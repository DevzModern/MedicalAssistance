﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace MediAssisApp
{
    public partial class DoctorLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPwd.Text;

            if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(password))
            {
                DataTable userDT = Models.LoginDetails.ValidateDocCredentials(email, password);
                if (userDT != null && userDT.Rows.Count == 0)
                {
                    lblLoginStatus.Text = "Wrong username or password";
                    lblLoginStatus.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    Session["DoctorId"] = Convert.ToString(userDT.Rows[0]["DoctorId"]);

                    Response.Redirect("~/Doctor/Dashboard.aspx");
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegisterDoctor.aspx");
        }
    }
}